package com.qianmo.stickyitemdecoration.bean;

/**
 * Created by wangjitao on 2017/3/3 0003.
 * E-Mail：543441727@qq.com
 */

public class NameBean {
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
