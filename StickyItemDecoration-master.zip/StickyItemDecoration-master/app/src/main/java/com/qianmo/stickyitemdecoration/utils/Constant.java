package com.qianmo.stickyitemdecoration.utils;


/**
 * Created by Administrator on 2016/11/8 0008.
 */
public class Constant {
    /**
     * 地址接口
     */
    public static final String BASE_URL = "http://api.meituan.com/mmdb/movie/";


}
