package com.qianmo.stickyitemdecoration.bean;

import java.util.List;

/**
 * Created by wangjitao on 2017/3/3 0003.
 * E-Mail：543441727@qq.com
 * 用于数据接收实体类
 */

public class MovieBean {

    private List<ComingBean> coming ;

    public List<ComingBean> getComing() {
        return coming;
    }

    public void setComing(List<ComingBean> coming) {
        this.coming = coming;
    }


}
